//Rohan Prasad and Cam Robbins

import java.sql.*;
import java.util.ArrayList;
import java.util.Scanner;

public class p3 {
    public static void main(String[] args) {
        String paramMsg;
        paramMsg = "Syntax:  java p3 <username> <password> <connection string> <menu item>\n"
                + "Include the following number of the menu item as your fourth parameter:\n"
                + "1 Report Location Information\n"
                + "2 Report Edge Information\n"
                + "3 Report CS Staff Information\n"
                + "4 Insert New Phone Extension\n";

        if (args.length != 4) {
            System.out.println("Syntax: java p3 <username> <password> <connection string> <menu item>\\n");
            System.out.println(paramMsg);
        }

        String USERID = args[0];
        String PASSWORD = args[1];
        String CONNECTIONSTRING = args[2];
        int MENUITEM = Integer.parseInt(args[3]);

        Connection connection = null;

        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            System.out.println("Where is your PostgreSQL JDBC Driver?");
        }

        System.out.println("PostgreSQL JDBC Driver Registered!");

        try {
            connection = DriverManager.getConnection(CONNECTIONSTRING, USERID, PASSWORD);

            switch (MENUITEM) {
                case (1): locations(connection); break;
                case (2): edges(connection); break;
                case (3): csstaff(connection); break;
                case (4): insertPhone(connection); break;
                default:
                    System.out.println("Invalid menu item choice. Choose a value from 1 to 4");
                    break;
            }

        } catch (SQLException e) {
            System.out.println("Connection Failed! Check output console");
            e.printStackTrace();
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public static void locations (Connection connection) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Location ID: ");
        String locationID = scanner.nextLine();

        String query = "SELECT * FROM locations WHERE locationID = ?";
        try {
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, locationID);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                System.out.println("Location Information");
                System.out.println("Location ID: " + resultSet.getString("locationID"));
                System.out.println("Location Name: " + resultSet.getString("locationName"));
                System.out.println("Location Type: " + resultSet.getString("LocationType"));
                System.out.println("X-Coordinate: " + resultSet.getString("xcoord"));
                System.out.println("Y-Coordinate: " + resultSet.getString("ycoord"));
                System.out.println("Floor: " + resultSet.getString("mapfloor"));
            } else {
                System.out.println("Location not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void edges(Connection connection) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Edge ID: ");
        String edgeID = scanner.nextLine();

        String query = "SELECT \n" +
                "    E.edgeID AS edgeID,\n" +
                "    SL.locationName AS \"Starting Location Name\",\n" +
                "    SL.mapFloor AS \"Starting Location Floor\",\n" +
                "    EL.locationName AS \"Ending Location Name\",\n" +
                "    EL.mapFloor AS \"Ending Location Floor\"\n" +
                "FROM \n" +
                "    Edges E\n" +
                "JOIN \n" +
                "    Locations SL ON E.startingLocationID = SL.locationID\n" +
                "JOIN \n" +
                "    Locations EL ON E.endingLocationID = EL.locationID\n" +
                "WHERE \n" +
                "    edgeID = ?";
        try {
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, edgeID);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                System.out.println("Edges Information");
                System.out.println("Edge ID: " + resultSet.getString("edgeID"));
                System.out.println("Starting location name: " + resultSet.getString("Starting Location Name"));
                System.out.println("Starting location floor: " + resultSet.getString("Starting Location Floor"));
                System.out.println("Ending location name: " + resultSet.getString("Ending Location Name"));
                System.out.println("Ending location floor: " + resultSet.getString("Ending Location Floor"));
            } else {
                System.out.println("Edge not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void csstaff(Connection connection) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter CS Staff Account Name: ");
        String accountName = scanner.nextLine();

        String query = "SELECT \n" +
                "    CS.accountName AS accountName,\n" +
                "    CS.firstName AS \"First Name\",\n" +
                "    CS.lastName AS \"Last Name\",\n" +
                "    CS.officeID AS \"Office ID\",\n" +
                "    T.titleName AS \"Title\",\n" +
                "    PE.phoneExt AS \"Phone Ext\"\n" +
                "FROM \n" +
                "    CSStaff CS\n" +
                "LEFT JOIN \n" +
                "    CSStaffTitles CST ON CS.accountName = CST.accountName\n" +
                "LEFT JOIN \n" +
                "    Titles T ON CST.acronym = T.acronym\n" +
                "LEFT JOIN \n" +
                "    PhoneExtensions PE ON CS.accountName = PE.accountName\n" +
                "WHERE CS.accountName = ?";
        try {
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, accountName);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                System.out.println("CS Staff Information");
                System.out.println("Account Name: " + resultSet.getString("accountName"));
                System.out.println("First Name: " + resultSet.getString("First Name"));
                System.out.println("Last Name: " + resultSet.getString("Last Name"));
                System.out.println("Office ID: " + resultSet.getString("Office ID"));

                ArrayList exts = new ArrayList();
                ArrayList titles = new ArrayList();

                exts.add(resultSet.getString("Phone Ext"));
                titles.add(resultSet.getString("Title"));

                while(resultSet.next()){
                    exts.add(resultSet.getString("Phone Ext"));
                    titles.add(resultSet.getString("Title"));
                }
                exts = removeDuplicates(exts);
                titles = removeDuplicates(titles);

                System.out.println("Title: " + titles);
                System.out.print("Phone Ext: " + exts);

            } else {
                System.out.println("CS Staff not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void insertPhone(Connection connection) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter CS Staff Account Name: ");
        String accountName = scanner.nextLine();
        System.out.print("Enter the new Phone Extension: ");
        String phoneExtension = scanner.nextLine();

        String query = "INSERT INTO phoneextensions(accountName, phoneExt) VALUES (?, ?)";
        try {
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, accountName);
            statement.setInt(2, Integer.parseInt(phoneExtension));
            int result = statement.executeUpdate();
            if (result > 0) {
                System.out.println("New phone extension added successfully.");
            } else {
                System.out.println("Failed to add new phone extension.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static <T> ArrayList<T> removeDuplicates(ArrayList<T> list)
    {
        ArrayList<T> newList = new ArrayList<T>();
        for (T element : list) {
            if (!newList.contains(element)) {
                newList.add(element);
            }
        }
        return newList;
    }

}